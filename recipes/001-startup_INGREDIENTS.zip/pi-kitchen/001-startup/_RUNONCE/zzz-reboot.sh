#!/bin/sh
echo "AUTOMATICALLY REBOOT IN 30 SECONDS"
sleep 30
sudo reboot