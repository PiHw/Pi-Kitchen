#!/bin/sh
echo "AUTOMATICALLY SHUTDOWN IN 30 SECONDS"
sudo shutdown -h -t 30