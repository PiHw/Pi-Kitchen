#!/bin/sh
sudo modprobe -v mt7601Usta
sudo depmod -a
echo "RaLink Wifi Adaptor Enabled [ra0]"
