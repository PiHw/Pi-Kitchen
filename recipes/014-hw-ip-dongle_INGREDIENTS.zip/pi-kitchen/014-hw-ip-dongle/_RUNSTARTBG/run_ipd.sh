#!/bin/sh
# We will assume this script is placed in the user's _RUNSTARTBG folder or similar
# and the ipd03.py file is in the user's bin folder.
sudo python ../ipd03.py