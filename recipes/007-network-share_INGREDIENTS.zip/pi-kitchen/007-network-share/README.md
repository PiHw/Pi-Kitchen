SMB network share

The smb.conf needs to be copied over after samba has been installed.
Since this will need internet connection to install samba and user prompt to set password, this must be run manually by the user.

sudo ~/bin/install_smbshare.sh

#Noobs Config#

`/home/pi/recovery/pi-kitchen/007-network-share/bin/install_smbshare.sh home/pi/bin`