#HW IP Display Dongle#

This recipe is intended to support the <a href="http://4tronix.co.uk/store/index.php?rt=product/product&product_id=390">PiHardware and 4tronix PiStop</a>:
<img src="https://raw.githubusercontent.com/PiHw/Pi-Stop/master/markdown_source/markdown/img/Pi-StopQuadFun.jpg"/>

##Running a demo automatically##
You will need to copy the `runpythonpirateE.sh` or `runtrafficlight.sh` to the NOOBS partition `_USER/_RUNSTARTBG` (recommended so you can adjust/remove easily) or use the `/home/pi/bin/_RUNSTARTBG` directory (which you can set the recipe file to copy).

For more information on the PiStop and the source files used for this recipe, see the <a href="https://github.com/PiHw/Pi-Stop"> PiStop Github</a>.

