cd /home/pi/recovery/pi-kitchen/015-hw-pistop-lighthouse/pistop/pirate/
sudo python3 piratecmd.py "W"