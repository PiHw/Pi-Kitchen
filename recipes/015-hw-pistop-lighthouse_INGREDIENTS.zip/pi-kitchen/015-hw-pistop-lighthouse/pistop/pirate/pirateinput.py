#!/usr/bin/python3

import pythonpirate

pythonpirate.playSiganl("N")
