#!/usr/bin/python3
#hello.py
print("Ahoy there Matey!")
