cd /home/pi/recovery/pi-kitchen/gpio/pistop/pirate/
sudo python3 piratecmd.py "E"
