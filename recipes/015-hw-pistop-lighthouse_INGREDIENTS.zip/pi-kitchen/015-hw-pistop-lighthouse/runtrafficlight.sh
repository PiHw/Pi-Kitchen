cd /home/pi/recovery/pi-kitchen/015-hw-pistop-lighthouse/pistop
sudo python3 trafficlights.py
