#!/bin/sh
sudo apt-get update
sudo apt-get install zd1211-firmware
sudo apt-get install firmware-ralink
sudo apt-get install firmware-brcn80211