#!/bin/sh
cd ..
sudo python3 shtdwn.py